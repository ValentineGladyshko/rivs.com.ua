<!--DOCTYPE html-->
<html lang="en">

<head>

	<title>
	ТОВ ТВД "РІВС" | Контакти
	</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta http-equiv="Content-Type" content="text/html"; charset="utf-8">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.css">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <link href="style.css" rel="stylesheet">
  <link href="googlemap.css" rel="stylesheet">
  
</head>
  <body>
      <header>
  <!--Navbar -->
  <nav class="mb-1 navbar sticky-top navbar-expand-lg navbar-light cyan accent-2 scrolling-navbar">
    <div class="container">
    <a class="navbar-brand" href="index.php">
        <img src="logo.png" width="30" height="40" alt="logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Головна
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="contacts.php">Контакти
              <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="store.php">Магазин</a>
        </li>
        </li>
      </ul>
    </div>
  </div>
  </nav>
</header>

<!--Main Navigation-->
  <!--Main layout-->
  <main class="mt-5 mb-3">
        <!--Main container-->
      <div class="container">
        <!--Grid row-->
        <div class="row">
  
          <!--Grid column-->
          <div class="col-md-7 mb-4">
            <div class="view overlay z-depth-1-half">
              <div class="mask rgba-white-light">
              </div>
            </div>
  
          </div>
          <!--Grid column-->
  
        </div>
        <!--Grid row-->
  
     <!-- Contact form -->
     <section class="mb-4">

      <!--Section heading-->
      <h2 class="h1-responsive font-weight-bold text-center my-4">Зв'язок із нами</h2>
      <!--Section description-->
      <p class="text-center w-responsive mx-auto mb-5">У вас є які-небудь питання? Будь ласка, не соромтеся звертатися до нас безпосередньо. Ми відповімо вам протягом 24 годин.</p>
      
      <div class="row">

        <!--Grid column-->
        <div class="col-md-8 col-xl-9">
            <form id ="contact-form" name="contact-form" action="ContactFormSubmit.php" method="POST"  onsubmit="return validateForm()" >

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form">
                            <div class="md-form">
                                <input type="text" id="name" name="name" class="form-control">
                                <label for="name" class="">Ваше ім'я</label>
                            </div>
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form">
                            <div class="md-form">
                                <input type="text" id="email" name="email" class="form-control">
                                <label for="email" class="">Ваш email</label>
                            </div>
                        </div>
                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->
                <div class="row">
                            <div class="col-md-12">
                                <div class="md-form">
                                    <input type="text" id="subject" name="subject" class="form-control">
                                    <label for="subject" class="">Тема листа</label>
                                </div>
                            </div>
                        </div>
                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-12">

                        <div class="md-form">
                            <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                            <label for="message">Введіть повідомлення</label>
                        </div>

                    </div>
                </div>
                <!--Grid row-->

            </form>

            <div class="center-on-small-only">
                <a class="btn btn-primary" onclick="validateForm()">Надіслати повідомлення</a>
            </div> 
            <div class="status" id="status"></div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-3 text-center">
          <ul class="list-unstyled mb-0">
              <li><i class="fas fa-map-marker-alt fa-2x"></i>
                  <p>Місто Київ, вулиця Північна 3</p>
              </li>

              <li><i class="fas fa-phone mt-4 fa-2x"></i>
                <p><a class="phone-ph" href="tel:+380674061192"><strong>+38(067)406-11-92 Київстар</strong></a></p>
                <p><a class="phone-ph" href="tel:+380507479297"><strong>+38(050)747-92-97 Vodafone</strong></a></p>
                  <a class="link waves-effect waves-light"> 
                    <p><a href="viber://chat?number=+380674061192"><i class="fab fa-viber fa-2x">Viber</i> </a></p>
                      <p><a href="https://t.me/rivs1"><i class="fab fa-telegram fa-2x">Telegram</i> </a></p>
                        <p><a href="https://wa.me/380957340508"><i class="fab fa-whatsapp fa-2x">WhatsApp</i></a></p>
                  </a>
              </li>

              <li><i class="fas fa-envelope mt-4 fa-2x"></i>
                  <p>rivs.com.ua@gmail.com</p>
              </li>
          </ul>
      </div>
        <!--Grid column-->

    </div>
  <div id="map-container" class="z-depth-1-half map-container">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d543.5598323529164!2d30.506472261855496!3d50.528346787935796!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4d248ea28a11d%3A0x33034c222f15706a!2z0LLRg9C70LjRhtGPINCf0ZbQstC90ZbRh9C90LAsIDUsINCa0LjRl9CyLCAwMjAwMA!5e0!3m2!1suk!2sua!4v1558130679616!5m2!1suk!2sua" style="border:0"  frameborder="0" style="border:0" allowfullscreen>></iframe>
        </div>
  </section>
      
      <!--Main container-->
  
    </main>
    <!--Main layout-->
  
    <!-- Footer -->
    <footer class="page-footer font-small bottom cyan accent-4 mt-4">

      <!-- Copyright -->
      <div class="footer-copyright text-center py-3">© 2015 - 2019 ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ — ТОРГОВО-ВИРОБНИЧИЙ ДІМ "РІВС"
      </div>
      <!-- Copyright -->
  
    </footer>
    <!-- Footer -->

     <!-- SCRIPTS -->
    <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
    <script>

      function validateForm() {
          
        document.getElementById('status').innerHTML = "Відправлення...";
        formData = {
        'name'     : $('input[name=name]').val(),
        'email'    : $('input[name=email]').val(),
        'subject'  : $('input[name=subject]').val(),
        'message'  : $('textarea[name=message]').val()
        };


        $.ajax({
        url : "ContactFormSubmit.php",
        type: "POST",
        data : formData,
        success: function(data, textStatus, jqXHR)
        {

        $('#status').text(data.message);
        if (data.code) 
        $('#contact-form').closest('form').find("input[type=text], textarea").val("");
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
        $('#status').text(jqXHR);
        }
        });
      }
          </script>
  </body>
  
</html>
