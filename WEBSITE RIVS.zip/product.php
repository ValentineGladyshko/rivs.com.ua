<?
    require_once('DatabaseRivsConnect.php');
    $PRODUCT = query_db('SELECT * FROM `pricelist` WHERE PriceListID = ' . $_GET['id'])[0];
?>
<!--DOCTYPE html-->
<html lang="en">

<head>

	<title>
	ТОВ ТВД "РІВС"
	</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <link href="style.css" rel="stylesheet">
  <link href="main.css" rel="stylesheet">
  
</head>
  <body>
      <header>
  <!--Navbar -->
  <nav class="mb-1 navbar sticky-top navbar-expand-lg navbar-light cyan accent-2 scrolling-navbar">
    <div class="container">
    <a class="navbar-brand" href="index.php">
        <img src="logo.png" width="30" height="40" alt="logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Головна
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contacts.php">Контакти</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="store.php">Магазин</a>
        </li>
        </li>
      </ul>
    </div>
  </div>
  </nav>
</header>

<!--Main Navigation-->

  <!--Main layout-->
  <main class="mt-5 mb-3">

      <!--Main container-->
      <div class="container">
        <div class="row">
            <div class="col-md-4">
            <img src="<?=$PRODUCT['Image'] ? $PRODUCT['Image'] : 'Store_photos/default.jpg';?>" 
                    class="img-fluid mx-auto"
                    alt="">
            </div>
            <div class="col-md-8">
            <h2 class="h1-responsive font-weight-bold text-center my-4"><?=$PRODUCT['ProductName'];?></h2>
              <p class="text-center w-responsive mx-auto mb-5"><?=$PRODUCT['Description'];?></p>
            </div>
        </div>

      </div>
      <!--Main container-->
  
    </main>
    <!--Main layout-->
  
    <!-- Footer -->
    <footer class="page-footer font-small bottom cyan accent-4 mt-4">

      <!-- Copyright -->
      <div class="footer-copyright text-center py-3">© 2015 - 2019 ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ — ТОРГОВО-ВИРОБНИЧИЙ ДІМ "РІВС"
      </div>
      <!-- Copyright -->
  
    </footer>
    <!-- Footer -->
    
  </body>

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>

</html>
